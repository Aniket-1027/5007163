public interface CustomerRepository {
    String findCustomerById(int id);
}
