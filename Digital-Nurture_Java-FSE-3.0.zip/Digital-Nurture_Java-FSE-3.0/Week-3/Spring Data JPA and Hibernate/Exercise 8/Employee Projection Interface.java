public interface EmployeeProjection {
    String getName();
    String getDepartment();
}
