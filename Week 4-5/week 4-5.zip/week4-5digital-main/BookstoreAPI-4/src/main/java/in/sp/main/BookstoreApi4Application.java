package in.sp.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookstoreApi4Application {

	public static void main(String[] args) {
		SpringApplication.run(BookstoreApi4Application.class, args);
	}

}
